# Errata for *AI for Healthcare with Keras and Tensorflow 2.0*

On **page xx** [Summary of error]:
 
Details of error here. Highlight key pieces in **bold**.

***

On **page xx** [Summary of error]:
 
Details of error here. Highlight key pieces in **bold**.

***