

$(document).ready(function(){
  $("#content-5").mCustomScrollbar({
    theme: "dark-thin"
  });
})