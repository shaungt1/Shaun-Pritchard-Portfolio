//Introductory12.cpp - displays the area of a square
//Created/revised by <your name> on <current date>

#include <iostream>
using namespace std;

int main()
{
	//instantiate a Square object
	
	//declare variable

	//get the measurement of one side of the square

	//assign the side measurement to the Square object

	//display the area of the square

	//system("pause");
	return 0;
}	//end of main function
