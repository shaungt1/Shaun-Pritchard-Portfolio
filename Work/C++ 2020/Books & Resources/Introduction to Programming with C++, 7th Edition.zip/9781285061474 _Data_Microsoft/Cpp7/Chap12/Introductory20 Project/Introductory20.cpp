//Introductory20.cpp - calculates and displays the
//average rate stored in a two-dimensional array
//Created/revised by <your name> on <current date>

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	double rates[5][3] = {{3.4, 56.7, 8.99}, 
						  {11.23, 4.67, 85.4},
					 	  {34.6, 2.4, 9.0},
						  {6.3, 8.0, 4.1},
						  {4.0, 2.0, 3.5}};


	//system("pause");
	return 0;
}	//end of main function