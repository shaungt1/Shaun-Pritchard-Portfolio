//Introductory21.cpp - displays the contents
//of a two-dimensional array, column by column
//and row by row
//Created/revised by <your name> on <current date>

#include <iostream>
using namespace std;

int main()
{
	int nums[2][4] = {{17, 24, 86, 35}, 
					  {23, 36, 10, 12}};

	//display column by column

	
	cout << endl;
	//display row by row


	//system("pause");
	return 0;
}	//end of main function