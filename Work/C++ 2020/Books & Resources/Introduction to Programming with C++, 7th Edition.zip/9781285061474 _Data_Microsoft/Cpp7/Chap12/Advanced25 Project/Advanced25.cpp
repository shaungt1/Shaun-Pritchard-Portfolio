//Advanced25.cpp - Displays the number of times
//the numbers from 1 through 9 appear in a
//two-dimensional array
//Created/revised by <your name> on <current date>

#include <iostream>
using namespace std;

int main()
{
	//declare numbers array
	int numbers[5][3] = {{1, 2, 7}, 
						{2, 5, 3}, 
						{1, 9, 4}, 
						{2, 6, 5}, 
						{7, 2, 2}};
	

	//system("pause");
	return 0;
}	//end of main function