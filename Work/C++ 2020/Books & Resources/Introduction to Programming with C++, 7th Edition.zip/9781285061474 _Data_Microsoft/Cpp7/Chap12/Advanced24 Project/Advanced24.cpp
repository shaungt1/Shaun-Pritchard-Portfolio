//Advanced24.cpp - Increases the prices stored in
//the first column in a two-dimensional array, and
//then stores the updated prices in the second column.
//Displays the contents of the array, row by row.
//Created/revised by <your name> on <current date>

#include <iostream>
using namespace std;

int main()
{
	int prices[5][2] = {{10, 0},
						{13, 0}, 
						{36, 0}, 
						{74, 0}, 
						{22, 0}};


	//system("pause");
	return 0;
}	//end of main function