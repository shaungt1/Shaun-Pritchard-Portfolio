//SwatTheBugs16.cpp
//Created/revised by <your name> on <current date>

#include <iostream>
using namespace std;

int main()
{
  	//declare variable
	double temp = 35.3;

	//increase variable's value by 1.5
	temp + 1.5 = temp;

	//display variable's value
	cout << "After adding 1.5, the temp variable now contains " << temp << "." << endl;

	//system("pause");
	return 0;
}	//end of main function