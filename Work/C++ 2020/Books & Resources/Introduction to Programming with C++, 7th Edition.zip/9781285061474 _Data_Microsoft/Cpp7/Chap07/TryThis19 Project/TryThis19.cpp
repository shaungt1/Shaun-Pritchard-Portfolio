//TryThis19.cpp - displays the quantity entered by the user
//Results in an endless loop
//Created/revised by <your name> on <current date>

#include <iostream>
using namespace std;

int main()
{
	int quantity = 0;

	while (quantity >= 0)
		cout << quantity << endl;
	//end while

	//system("pause");
	return 0;
}	//end of main function
