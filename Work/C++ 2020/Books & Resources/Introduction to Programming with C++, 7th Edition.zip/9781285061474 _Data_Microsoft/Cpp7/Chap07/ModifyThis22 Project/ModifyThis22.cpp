//ModifyThis22.cpp - displays the word "Hello" 10 times
//Created/revised by <your name> on <current date>

#include <iostream>
using namespace std;

int main()
{
	int counter = 1;

	while (counter < 11)
	{
		cout << "Hello" << endl;
		counter += 1;
	}	//end while

	//system("pause");
	return 0;
}	//end of main function