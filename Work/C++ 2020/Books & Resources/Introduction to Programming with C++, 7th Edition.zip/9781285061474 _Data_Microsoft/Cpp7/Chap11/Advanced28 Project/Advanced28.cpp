//Advanced28.cpp - displays the number of students
//earning a specific score
//Created/revised by <your name> on <current date>

#include <iostream>
using namespace std;

int main()
{
	//declare array
	int scores[20] = {90, 54, 23, 75, 67, 89, 99, 100, 34, 99, 
					  97, 76, 73, 72, 56, 73, 72, 20, 86, 99};


	//system("pause");
	return 0;
}	//end of main function