//Advanced34.cpp - displays the price and quantity
//associated with a product ID
//Created/revised by <your name> on <current date>

#include <iostream>
using namespace std;

int main()
{
	//declare arrays
	int ids[5]        = {10, 14, 34, 45, 78};
	int prices[5]     = {125, 600, 250, 350, 225};
	int quantities[5] = {5, 3, 9, 10, 2};


	//system("pause");
	return 0;
}	//end of main function