//Introductory21.cpp - displays the average rate
//Created/revised by <your name> on <current date>

#include <iostream>
using namespace std;

int main()
{
	double rates[5] = {3.4, 56.7, 8.99, 11.23, 4.67};
	double sum = 0.0;

	cout << "Average: " << sum / 5.0 << endl;

	//system("pause");
	return 0;
}	//end of main function