
/*
Author: Shaun Pritchard
Date: 01-26-2020
FileName: creg.cpp
Purpose: simulates a simple cash register application that will take 5 inputs and toal the input amounts add a 7% tax and toal that amount, 
and disaplay over all item total plus tax added toal as a final subtaol amount.
Output: Outputs various information based on input values float, integer, and string values.
Exceptions: None.

*/
#include <iostream>
#include <cstdlib>

using namespace std;

int main()
{
   // Variable declaration
  
   const float taxRate = 7;
   float itemCost [5];
   float itemTax[5];
   float itemSubTotal[5];
  
   float itemTotal = 0;
   float taxTotal = 0;
   float totalDue = 0;
  
   // Decimal point display
   cout.precision(2);
   cout.setf(ios::fixed);
  
   // Take input values
  
   for (int i=0; i<5; i++){
       cout <<"Please enter item cost: ";
       cin>>itemCost[i];
      
       // Calculate tax and sub totalDue
     
       itemTax[i] = (itemCost[i] * taxRate) /100;
       itemSubTotal[i] = itemCost[i] + itemTax[i];
      
       // Calculate Item Total, Tax Total and Total Due
       itemTotal =  itemCost[i] + itemTotal;
       taxTotal =  itemTax[i] + taxTotal;
       totalDue =  itemSubTotal[i] + totalDue;
   }
  
  
   // Headings
  
   cout<<"Item Cost \t\t Item Tax \t\t Item Subtotal"<<endl;
   cout<<"--------------------------------------------------------------------------"<<endl;
  
   for ( int i=0; i<5; i++){
       cout <<"\t"<<itemCost[i]<<"\t\t\t"<<itemTax[i]<<"\t\t\t"<<itemSubTotal[i]<<endl;
   }
    cout <<"--------------------------------------------------------------------------"<<endl;


    // Display Item Total, Tax Total and Total Due
   cout <<right<<"\t"<<"Items Total"<<"\t\t"<<"Tax Total %"<<"\t\t"<<"Total Due"<<endl;
   cout <<"\t"<<"$"<<itemTotal<<"\t\t\t"<<taxTotal<<"%"<<"\t\t\t"<<"$"<<totalDue<<endl;
   
  
    return 0;
}